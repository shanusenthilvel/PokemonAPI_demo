
const Data = 
{
  heading: "Name - Abilities Selector",
  drop1:
  [
    {
      "ability":
      {     
        "name": "charmeleon",    
        "url": "https://pokeapi.co/api/v2/pokemon/5/" 
      }
    },
     
    {
      "ability": 
      {
        "name": "bulbasaur",
        "url": "https://pokeapi.co/api/v2/pokemon/1/"
      }
    },
     
    {    
      "ability": 
      {     
        "name": "squirtle",     
        "url": "https://pokeapi.co/api/v2/pokemon/7/"     
      }
    },
     
    {     
      "ability": 
      { 
        "name": "weedle",
        "url": "https://pokeapi.co/api/v2/pokemon/13/"
      }
    }
   
  ],
    
}
export default Data;
























 /*countries:[
    {
      "name": "charmeleon",
      "url": "https://pokeapi.co/api/v2/pokemon/5/"
    },
    {
      "name": "charizard",
      "url": "https://pokeapi.co/api/v2/pokemon/6/"
    },
    {
      "name": "squirtle",
      "url": "https://pokeapi.co/api/v2/pokemon/7/"
    },
    {
      "name": "wartortle",
      "url": "https://pokeapi.co/api/v2/pokemon/8/"
    }
  ]*/