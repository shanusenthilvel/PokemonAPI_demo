
import React, { Component } from 'react';
import Data from '../mock/valuesMock'
import '../styles/App.css'
import PokemonList from './pokemonList'

class App extends Component {
  render() {
    return (
      <div>
        <PokemonList Content={this.props.Content} />
      </div>
    );
  }
}
App.defaultProps = { Content: Data }
export default App;